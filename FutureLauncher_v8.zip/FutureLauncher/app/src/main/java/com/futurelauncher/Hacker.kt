@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.futurelauncher

import android.content.SharedPreferences
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Mono = FontFamily.Monospace
private const val RAIN = "01アイウエオカキクケコサシスセソ<>/{}[]#%=+"

/** Chuva de código sutil no fundo da gaveta, na cor do tema. */
@Composable
private fun CodeRain(accent: Color, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "rain")
    val ph by t.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "ph")
    val paint = remember { android.graphics.Paint().apply { isAntiAlias = true; typeface = android.graphics.Typeface.MONOSPACE } }
    Canvas(modifier) {
        val cell = 16.dp.toPx()
        paint.textSize = cell * 0.9f
        val cols = (size.width / cell).toInt()
        val rows = (size.height / cell).toInt() + 1
        val period = rows + 14
        var c = 0
        while (c < cols) {
            val speed = 1 + (c * 7) % 3
            val head = (ph * speed * period + c * 13f) % period
            for (k in 0 until 12) {
                val r = (head - k).toInt()
                if (r < 0 || r > rows) continue
                val a = (1f - k / 12f) * (if (k == 0) 0.55f else 0.20f)
                paint.color = accent.copy(alpha = a).toArgb()
                val idx = ((c * 31 + r * 17 + (ph * 40f).toInt() * (k + 1)) % RAIN.length + RAIN.length) % RAIN.length
                drawContext.canvas.nativeCanvas.drawText(RAIN[idx].toString(), c * cell, r * cell, paint)
            }
            c += 2
        }
    }
}

/** Linhas horizontais finas, estilo monitor CRT. */
@Composable
private fun Scanlines(modifier: Modifier) {
    Canvas(modifier) {
        val step = 3.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(Color.Black.copy(alpha = 0.22f), Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

@Composable
private fun HackTab(t: String, on: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        t.uppercase(), fontFamily = Mono, fontSize = 12.sp, color = if (on) Color.Black else accent.copy(alpha = 0.85f),
        modifier = Modifier.background(if (on) accent else Color.Transparent)
            .border(1.dp, accent.copy(alpha = if (on) 1f else 0.35f))
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
private fun HackIcon(app: AppInfo, shape: IconShape, size: Dp, theme: Theme, duo: Boolean, fav: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val s = shape.toShape()
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.85f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "hp")
    Column(
        Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.icon, contentDescription = app.label,
            modifier = Modifier.size(size).clip(s).background(Color.Black.copy(alpha = 0.6f))
                .then(if (duo) Modifier.duotone(theme.a, theme.b) else Modifier)
                .border(1.dp, theme.a.copy(alpha = if (pressed) 1f else 0.5f), s)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            (if (fav) "★" else "") + app.label.lowercase(), color = theme.a, fontFamily = Mono, fontSize = 10.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.width(size + 12.dp)
        )
    }
}

@Composable
fun DrawerPage(
    apps: List<AppInfo>, shape: IconShape, size: Float, duo: Boolean, theme: Theme,
    prefs: SharedPreferences, favs: Set<String>, launch: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit
) {
    val accent = theme.a
    val dim = accent.copy(alpha = 0.55f)
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var view by remember { mutableStateOf(prefs.getInt("dview", 0)) }
    val groups = remember(apps) { (1..4).filter { g -> apps.any { group(it.cat) == g } } }
    val list = remember(apps, query, tab, favs) {
        apps.filter { a -> a.label.contains(query, true) && when (tab) { 0 -> true; -1 -> a.pkg in favs; else -> group(a.cat) == tab } }
    }
    val letters = remember(list) { list.map { letterOf(it.label) }.distinct() }
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    var barH by remember { mutableStateOf(1f) }
    var active by remember { mutableStateOf<Char?>(null) }
    val s = shape.toShape()

    val prompt = "future@launcher:~\$ ls -la /apps"
    var typed by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { for (c in prompt) { typed += c; delay(28) } }
    val inf = rememberInfiniteTransition(label = "cursor")
    val cur by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(530), RepeatMode.Reverse), label = "cur")

    fun jump(y: Float) {
        if (letters.isEmpty()) return
        val c = letters[(y / barH * letters.size).toInt().coerceIn(0, letters.size - 1)]
        if (c != active) {
            active = c
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            val idx = list.indexOfFirst { letterOf(it.label) == c }.coerceAtLeast(0)
            scope.launch { if (view == 0) gridState.scrollToItem(idx) else listState.scrollToItem(idx) }
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF010402).copy(alpha = 0.82f))) {
        CodeRain(accent, Modifier.fillMaxSize())
        Scanlines(Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 6.dp)) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(typed, color = accent, fontFamily = Mono, fontSize = 13.sp)
                    Text("█", color = accent.copy(alpha = if (cur > 0.5f) 1f else 0f), fontFamily = Mono, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (view == 0) "[LIST]" else "[GRID]", color = accent, fontFamily = Mono, fontSize = 12.sp,
                        modifier = Modifier.clickable { view = 1 - view; prefs.edit().putInt("dview", view).apply() }.padding(10.dp)
                    )
                }
                Text("total ${list.size} // ${tr("tema", "theme")}: ${theme.name.lowercase()}", color = dim, fontFamily = Mono, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().padding(end = 10.dp).background(Color.Black.copy(alpha = 0.55f))
                        .border(1.dp, accent.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("grep -i ", color = accent, fontFamily = Mono, fontSize = 14.sp)
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(tr("nome do app…", "app name…"), color = dim.copy(alpha = 0.5f), fontFamily = Mono, fontSize = 14.sp)
                        BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontFamily = Mono), cursorBrush = SolidColor(accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { launch(it) } }),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HackTab(tr("Todos", "All"), tab == 0, accent) { tab = 0 }
                    HackTab("★", tab == -1, accent) { tab = -1 }
                    groups.forEach { g -> HackTab(groupName(g), tab == g, accent) { tab = g } }
                }
                if (list.isEmpty()) {
                    Text(
                        if (tab == -1) tr("> segure um app e escolha ★ Favoritar", "> long-press an app and choose ★ Favorite") else tr("> nada encontrado", "> no matches"),
                        color = dim, fontFamily = Mono, fontSize = 13.sp, modifier = Modifier.padding(20.dp)
                    )
                } else if (view == 0) {
                    LazyVerticalGrid(GridCells.Adaptive(size.dp + 28.dp), Modifier.fillMaxSize(), state = gridState, contentPadding = PaddingValues(end = 22.dp)) {
                        gridItems(list, key = { it.pkg }) { app -> HackIcon(app, shape, size.dp, theme, duo, app.pkg in favs, { launch(app) }, { onLong(app) }) }
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(end = 22.dp)) {
                        itemsIndexed(list, key = { _, a -> a.pkg }) { i, app ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .combinedClickable(onClick = { launch(app) }, onLongClick = { onLong(app) })
                                    .drawBehind { drawLine(accent.copy(alpha = 0.12f), Offset(0f, this.size.height), Offset(this.size.width, this.size.height), 1f) }
                                    .padding(vertical = 7.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("[%02d]".format(i + 1), color = dim, fontFamily = Mono, fontSize = 12.sp)
                                Spacer(Modifier.width(10.dp))
                                Image(
                                    bitmap = app.icon, contentDescription = app.label,
                                    modifier = Modifier.size(40.dp).clip(s).background(Color.Black.copy(alpha = 0.6f))
                                        .then(if (duo) Modifier.duotone(theme.a, theme.b) else Modifier)
                                        .border(1.dp, accent.copy(alpha = 0.45f), s)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(app.label.lowercase(), color = Color.White, fontFamily = Mono, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(app.pkg, color = accent.copy(alpha = 0.45f), fontFamily = Mono, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (app.pkg in favs) Text("★", color = accent, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
            if (letters.size > 1) {
                Column(
                    Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.7f).width(22.dp).onSizeChanged { barH = it.height.toFloat() }
                        .pointerInput(letters) { detectTapGestures(onTap = { jump(it.y); scope.launch { delay(400); active = null } }) }
                        .pointerInput(letters) { detectDragGestures(onDragStart = { jump(it.y) }, onDragEnd = { active = null }, onDragCancel = { active = null }) { change, _ -> jump(change.position.y) } },
                    verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    letters.forEach { Text(it.toString(), fontSize = 10.sp, fontFamily = Mono, color = if (it == active) accent else accent.copy(alpha = 0.5f)) }
                }
            }
            active?.let {
                Box(
                    Modifier.align(Alignment.Center).size(96.dp).background(Color.Black.copy(alpha = 0.85f)).border(1.dp, accent),
                    contentAlignment = Alignment.Center
                ) { Text(it.toString(), fontSize = 52.sp, fontFamily = Mono, color = accent) }
            }
        }
    }
}
