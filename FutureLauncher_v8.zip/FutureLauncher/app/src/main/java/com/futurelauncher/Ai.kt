package com.futurelauncher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

val AiProviders = listOf("Claude", "OpenAI", "Gemini", "OpenRouter")

val PersonaNames = listOf("Spencer", "Kristen")

/** Rascunhos meus de como cada personalidade age. São editáveis nas configurações. */
val PersonaDefaults = listOf(
    "Você é Spencer: direto, estratégico e analítico. Explica o mecanismo por trás das coisas, separa fato de inferência e de hipótese e questiona premissas. Sem enrolação e sem clichê motivacional.",
    "Você é Kristen: calorosa, organizada e prática. Transforma ideias em passos curtos, lembra prazos e ajuda a executar, celebrando o progresso sem exagero."
)

fun aiSystem(persona: String) = persona.trim() + " " + tr("Você está dentro de um launcher Android: responda curto.", "You are inside an Android launcher: reply short.")

/** Modelo sugerido por provedor. Nomes de modelo mudam com o tempo: o campo é editável nas configurações. */
fun aiDefaultModel(p: Int) = when (p) { 0 -> "claude-haiku-5-5"; 1 -> "gpt-4o-mini"; 2 -> "gemini-2.5-flash"; else -> "openrouter/auto" }

data class Msg(val fromUser: Boolean, val text: String)

/** Chamada HTTP direta ao provedor escolhido, sem biblioteca extra. A chave só sai do aparelho rumo ao próprio provedor. */
suspend fun askAi(provider: Int, key: String, model: String, history: List<Msg>, sys: String): String = withContext(Dispatchers.IO) {
    try {
        val url: String
        val headers: Map<String, String>
        val body: String
        when (provider) {
            0 -> {
                url = "https://api.anthropic.com/v1/messages"
                headers = mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
                val arr = JSONArray()
                history.forEach { arr.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
                body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", sys).put("messages", arr).toString()
            }
            1, 3 -> {
                url = if (provider == 1) "https://api.openai.com/v1/chat/completions" else "https://openrouter.ai/api/v1/chat/completions"
                headers = mapOf("Authorization" to "Bearer $key")
                val arr = JSONArray()
                arr.put(JSONObject().put("role", "system").put("content", sys))
                history.forEach { arr.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
                body = JSONObject().put("model", model).put("messages", arr).toString()
            }
            else -> {
                url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                headers = mapOf("x-goog-api-key" to key)
                val arr = JSONArray()
                history.forEach {
                    arr.put(JSONObject().put("role", if (it.fromUser) "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", it.text))))
                }
                body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", arr).toString()
            }
        }
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val m = try {
                val j = JSONObject(text)
                j.optJSONObject("error")?.optString("message") ?: j.optString("error")
            } catch (e: Exception) { null }
            return@withContext "HTTP $code: " + (if (!m.isNullOrBlank()) m else text.take(200))
        }
        val j = JSONObject(text)
        when (provider) {
            0 -> j.getJSONArray("content").getJSONObject(0).getString("text")
            1, 3 -> j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            else -> j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }.trim()
    } catch (e: Exception) {
        tr("Falha de conexão: ", "Connection failed: ") + (e.message ?: "")
    }
}

/** Painel de conversa: fala (reconhecimento do próprio sistema, sem permissão de microfone) ou digita. */
@Composable
fun AiChat(theme: Theme, provider: Int, key: String, model: String, persona: Int, personaPrompt: String, onPersona: (Int) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val accent = theme.a
    val dim = Color.White.copy(alpha = 0.5f)
    val scope = rememberCoroutineScope()
    var msgs by remember { mutableStateOf(listOf<Msg>()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    fun send(t: String) {
        if (t.isBlank() || busy) return
        msgs = msgs + Msg(true, t.trim())
        input = ""
        busy = true
        scope.launch {
            val r = askAi(provider, key, model, msgs, aiSystem(personaPrompt))
            msgs = msgs + Msg(false, r)
            busy = false
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }

    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        try { speech.launch(i) } catch (e: Exception) {
            Toast.makeText(ctx, tr("Reconhecimento de voz indisponível, digite", "Voice recognition unavailable, type instead"), Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) { listen() }
    LaunchedEffect(msgs.size, busy) {
        val n = msgs.size + (if (busy) 1 else 0)
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp).fillMaxHeight(0.72f)
                .clip(RoundedCornerShape(24.dp)).background(Color(0xFF0B0620).copy(alpha = 0.97f))
                .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(24.dp)).padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${AiProviders[provider]} · $model", color = dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                PersonaNames.forEachIndexed { i, n ->
                    Text(n, color = if (i == persona) accent else dim, fontSize = 12.sp, modifier = Modifier.clickable { onPersona(i) }.padding(8.dp))
                }
                Text(tr("limpar", "clear"), color = accent, fontSize = 12.sp, modifier = Modifier.clickable { msgs = emptyList() }.padding(8.dp))
                Text("✕", color = Color.White, fontSize = 18.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (msgs.isEmpty()) item { Text(tr("Fale ou digite. Toque numa resposta pra copiar.", "Speak or type. Tap a reply to copy."), color = dim, fontSize = 13.sp, modifier = Modifier.padding(8.dp)) }
                items(msgs) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(
                            m.text, color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(16.dp))
                                .background(if (m.fromUser) accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.10f))
                                .then(
                                    if (!m.fromUser) Modifier.clickable {
                                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ai", m.text))
                                        Toast.makeText(ctx, tr("Copiado", "Copied"), Toast.LENGTH_SHORT).show()
                                    } else Modifier
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                if (busy) item { Text("…", color = accent, fontSize = 20.sp, modifier = Modifier.padding(8.dp)) }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).glass(RoundedCornerShape(24.dp), accent).padding(horizontal = 14.dp, vertical = 11.dp)) {
                    if (input.isEmpty()) Text(tr("Pergunte algo…", "Ask something…"), color = dim, fontSize = 15.sp)
                    BasicTextField(
                        value = input, onValueChange = { input = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = SolidColor(accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send(input) }),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text("🎤", fontSize = 22.sp, modifier = Modifier.clickable { listen() }.padding(10.dp))
                Text("➤", color = accent, fontSize = 22.sp, modifier = Modifier.clickable { send(input) }.padding(10.dp))
            }
        }
    }
}
