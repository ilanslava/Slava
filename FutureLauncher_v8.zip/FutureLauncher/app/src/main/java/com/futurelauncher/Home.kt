@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.futurelauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private const val RS = "\u001E"
private const val FS = "\u001F"

fun SharedPreferences.list(key: String, seed: List<Pair<String, String>>): List<Pair<String, String>> {
    val raw = getString(key, null) ?: return seed
    return raw.split(RS).filter { it.contains(FS) }.map { val p = it.split(FS, limit = 2); p[0] to p[1] }
}

fun SharedPreferences.saveList(key: String, l: List<Pair<String, String>>) {
    edit().putString(key, l.joinToString(RS) { it.first + FS + it.second }).apply()
}

fun seedLinks() = listOf(
    "YouTube" to "app:com.google.android.youtube", "WhatsApp" to "app:com.whatsapp", "Instagram" to "app:com.instagram.android",
    "ChatGPT" to "app:com.openai.chatgpt", "Claude" to "app:com.anthropic.claude", "Facebook" to "app:com.facebook.katana"
)

fun openLink(ctx: Context, url: String) {
    runCatching {
        if (url.startsWith("app:")) {
            val pkg = url.removePrefix("app:")
            ctx.startActivity(ctx.packageManager.getLaunchIntentForPackage(pkg) ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } else ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}

fun igOpen(ctx: Context, uri: String) {
    val ok = runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage("com.instagram.android")) }.isSuccess
    if (!ok) openLink(ctx, "app:com.instagram.android")
}

fun liveLines(hour: Int, battery: Int): List<String> {
    val l = mutableListOf<String>()
    l += when (hour) {
        in 5..11 -> tr("Bom dia! ☀️ Bora fazer o dia render?", "Good morning! ☀️ Ready to make today count?")
        in 12..17 -> tr("Boa tarde! 🌤 Já bebeu água hoje? 💧", "Good afternoon! 🌤 Had some water today? 💧")
        in 18..22 -> tr("Boa noite! 🌙 Hora de desacelerar um pouco.", "Good evening! 🌙 Time to slow down a bit.")
        else -> tr("Ainda acordado? 🦉 Não esquece de descansar.", "Still up? 🦉 Don't forget to rest.")
    }
    if (battery in 1..20) l += tr("Bateria em $battery%… cadê o carregador? 🔋", "Battery at $battery%… where's the charger? 🔋")
    l += tr("Dica: digite \"timer 33\" na barra lá em cima.", "Tip: type \"timer 33\" in the bar up top.")
    l += tr("Toque em mim pra falar com o Google 🎤", "Tap me to talk to Google 🎤")
    l += tr("Segure um app na gaveta pra favoritar ★", "Long-press an app in the drawer to favorite ★")
    return l
}

@Composable
fun LiveAssistant(theme: Theme, lines: List<String>, say: String, onTap: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    var shown by remember { mutableStateOf("") }
    var blink by remember { mutableStateOf(false) }
    var look by remember { mutableStateOf(0) }
    var bounce by remember { mutableStateOf(false) }
    LaunchedEffect(lines, say) {
        if (say.isNotEmpty()) { shown = ""; for (c in say) { shown += c; delay(20) }; return@LaunchedEffect }
        var i = 0
        while (true) { val l = lines[i % lines.size]; shown = ""; for (c in l) { shown += c; delay(30) }; delay(5500); i++ }
    }
    LaunchedEffect(Unit) { while (true) { delay((2500L..5000L).random()); blink = true; delay(140); blink = false } }
    LaunchedEffect(Unit) { while (true) { delay((1800L..3600L).random()); look = (-1..1).random() } }
    LaunchedEffect(bounce) { if (bounce) { delay(160); bounce = false } }
    val t = rememberInfiniteTransition(label = "orb")
    val breathe by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val lookX by animateFloatAsState(look * 3f, tween(350), label = "l")
    val squash by animateFloatAsState(if (bounce) 0.8f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "s")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(
            Modifier.size(64.dp)
                .pointerInput(Unit) { detectTapGestures { bounce = true; haptic.performHapticFeedback(HapticFeedbackType.LongPress); onTap() } }
                .graphicsLayer { scaleX = breathe * squash; scaleY = breathe * squash }
        ) {
            val c = Offset(size.width / 2, size.height / 2)
            drawCircle(Brush.radialGradient(listOf(theme.a.copy(alpha = 0.45f), Color.Transparent), c, size.width / 2), radius = size.width / 2, center = c)
            drawCircle(Brush.linearGradient(listOf(theme.a, theme.b)), radius = size.width * 0.30f, center = c)
            val eyeH = if (blink) 2.dp.toPx() else 11.dp.toPx()
            val ew = 6.dp.toPx()
            for (dx in listOf(-8f, 8f)) {
                val cx = c.x + dx.dp.toPx() + lookX.dp.toPx()
                drawOval(Color.White, Offset(cx - ew / 2, c.y - eyeH / 2), Size(ew, eyeH))
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(shown, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f).glass(RoundedCornerShape(20.dp), theme.a).padding(horizontal = 14.dp, vertical = 10.dp))
    }
}

fun group(c: Int) = when (c) {
    ApplicationInfo.CATEGORY_SOCIAL -> 1
    ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> 2
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> 3
    ApplicationInfo.CATEGORY_GAME -> 4
    else -> 0
}

fun groupName(g: Int) = when (g) { 1 -> "Social"; 2 -> tr("Mídia", "Media"); 3 -> tr("Trabalho", "Work"); else -> tr("Jogos", "Games") }

fun letterOf(s: String): Char = s.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'

@Composable
fun Opt(label: String, onClick: () -> Unit) {
    Text(label, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

@Composable
fun SectionLabel(t: String) {
    Text(t, fontSize = 12.sp, color = Color.White.copy(alpha = 0.55f), modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 6.dp))
}

@Composable
fun TabChip(t: String, on: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        t, color = if (on) Color.Black else Color.White, fontSize = 13.sp,
        modifier = Modifier.clip(CircleShape).background(if (on) accent else Color.White.copy(alpha = 0.10f)).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun ClockText(now: LocalDateTime, theme: Theme, size: Int) {
    Text(
        now.format(DateTimeFormatter.ofPattern("HH:mm")),
        style = TextStyle(brush = Brush.linearGradient(listOf(Color.White, theme.a, theme.b)), fontSize = size.sp, fontWeight = FontWeight.Thin)
    )
}

@Composable
fun AddDialog(title: String, l1: String, l2: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(a, { a = it }, label = { Text(l1) }, singleLine = true)
                OutlinedTextField(b, { b = it }, label = { Text(l2) })
            }
        },
        confirmButton = { TextButton(onClick = { if (a.isNotBlank() && b.isNotBlank()) onSave(a.trim(), b.trim()) }) { Text(tr("Salvar", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancelar", "Cancel")) } }
    )
}

@Composable
fun Hub(prefs: SharedPreferences, theme: Theme, now: LocalDateTime, date: String, apps: List<AppInfo>) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val accent = theme.a
    var links by remember { mutableStateOf(prefs.list("links", seedLinks())) }
    var add by remember { mutableStateOf("") }
    var delLink by remember { mutableStateOf(-1) }
    val tile = RoundedCornerShape(20.dp)

    Row(verticalAlignment = Alignment.Bottom) {
        ClockText(now, theme, 60)
        Spacer(Modifier.width(12.dp))
        Text(date, fontSize = 15.sp, color = accent, modifier = Modifier.padding(bottom = 10.dp))
    }

    SectionLabel(tr("Atalhos", "Shortcuts"))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        links.forEachIndexed { i, (name, url) ->
            Column(
                Modifier.size(78.dp, 72.dp).glass(tile, accent).combinedClickable(
                    onClick = { openLink(ctx, url) },
                    onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); delLink = i }
                ),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                val ic = apps.firstOrNull { "app:" + it.pkg == url }?.icon
                if (ic != null) Image(ic, name, Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)))
                else Text(name.take(1).uppercase(), fontSize = 22.sp, color = accent, fontWeight = FontWeight.Medium)
                Text(name, fontSize = 11.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
        Box(Modifier.size(78.dp, 72.dp).glass(tile, accent).clickable { add = "link" }, contentAlignment = Alignment.Center) { Text("+", fontSize = 26.sp, color = accent) }
    }

    SectionLabel(tr("Enviar pro Instagram", "Post to Instagram"))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("📸 Story" to "instagram://story-camera", "🎬 Reels" to "instagram://reels-camera", "🖼 Post" to "instagram://library").forEach { (l, u) ->
            Text(l, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f).glass(CircleShape, accent).clickable { igOpen(ctx, u) }.padding(vertical = 11.dp))
        }
    }

    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), accent).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text(tr("Foco", "Focus"), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
            Text("33 min", fontSize = 34.sp, color = accent, fontWeight = FontWeight.Light)
        }
        Text(
            "⏱ 33′", color = Color.White, fontSize = 14.sp,
            modifier = Modifier.glass(CircleShape, accent).clickable {
                runCatching {
                    ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, 1980).putExtra(AlarmClock.EXTRA_MESSAGE, "33").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    Toast.makeText(ctx, tr("Timer de 33 min iniciado", "33 min timer started"), Toast.LENGTH_SHORT).show()
                }
            }.padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }

    if (add == "link") AddDialog(tr("Novo atalho", "New shortcut"), tr("Nome", "Name"), tr("Link, número ou e-mail", "Link, number or email"), { add = "" }) { n, u ->
        val url = when {
            u.contains(":") -> u
            u.all { it.isDigit() || it in "+ -()" } -> "https://wa.me/" + u.filter { it.isDigit() }
            u.contains("@") -> "mailto:$u"
            else -> "https://$u"
        }
        links = links + (n to url); prefs.saveList("links", links); add = ""
    }
    if (delLink >= 0 && delLink < links.size) AlertDialog(
        onDismissRequest = { delLink = -1 }, title = { Text(links[delLink].first) },
        confirmButton = { TextButton(onClick = { links = links.filterIndexed { i, _ -> i != delLink }; prefs.saveList("links", links); delLink = -1 }) { Text(tr("Remover", "Remove")) } },
        dismissButton = { TextButton(onClick = { delLink = -1 }) { Text(tr("Cancelar", "Cancel")) } }
    )
}

@Composable
fun HomePage(
    dockApps: List<AppInfo>, top: List<AppInfo>, shape: IconShape, size: Float, duo: Boolean, theme: Theme, count: Int,
    layout: Int, prefs: SharedPreferences, apps: List<AppInfo>,
    openDrawer: () -> Unit, openSettings: () -> Unit, openAssistant: () -> Unit, onCommand: (String) -> String,
    launch: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit, themeIdx: Int, onTheme: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val accent = theme.a
    var fanOpen by remember { mutableStateOf(false) }
    var orbCenter by remember { mutableStateOf(Offset.Zero) }
    val now by produceState(LocalDateTime.now()) { while (true) { value = LocalDateTime.now(); delay(1000) } }
    val battery by produceState(0) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) { value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); delay(30000) }
    }
    var cmd by remember { mutableStateOf("") }
    var fb by remember { mutableStateOf("") }
    LaunchedEffect(fb) { if (fb.isNotEmpty()) { delay(5000); fb = "" } }
    val date = now.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale.getDefault())).replaceFirstChar { it.uppercase() }
    val lines = remember(now.hour, battery / 10, now.minute / 10) { liveLines(now.hour, battery) }
    val greeting = when (now.hour) { in 5..11 -> tr("Bom dia", "Good morning"); in 12..17 -> tr("Boa tarde", "Good afternoon"); else -> tr("Boa noite", "Good evening") }

    Box(Modifier.fillMaxSize()) {
    LivingOrbs(theme, Modifier.fillMaxSize())
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).glass(RoundedCornerShape(28.dp), accent).padding(horizontal = 18.dp, vertical = 14.dp)) {
                if (cmd.isEmpty()) Text(tr("Digite um comando… (ex.: alarme 7:30)", "Type a command… (e.g. alarm 7:30 am)"), color = Color.White.copy(alpha = 0.5f), fontSize = 15.sp)
                BasicTextField(
                    value = cmd, onValueChange = { cmd = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp), cursorBrush = SolidColor(accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { fb = onCommand(cmd); cmd = "" }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text("🎤", fontSize = 22.sp, modifier = Modifier.clickable { openAssistant() }.padding(10.dp))
            ThemeOrb(theme, fanOpen, { fanOpen = !fanOpen }) { orbCenter = it }
            Text("⚙", fontSize = 24.sp, color = Color.White.copy(alpha = 0.8f), modifier = Modifier.clickable { openSettings() }.padding(12.dp))
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        LiveAssistant(theme, lines, fb, openAssistant)
        Spacer(Modifier.height(10.dp))
        when (layout) {
            0 -> {
                Spacer(Modifier.height(40.dp))
                ClockText(now, theme, 110)
                Text(date, fontSize = 18.sp, color = accent)
            }
            2 -> Hub(prefs, theme, now, date, apps)
            else -> {
                ClockText(now, theme, 96)
                Text(date, fontSize = 18.sp, color = accent)
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), accent).padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(greeting, fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Medium)
                        Text(tr("$count apps instalados", "$count apps installed"), fontSize = 13.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val w = 7.dp.toPx()
                            val tl = Offset(w, w)
                            val sz = Size(this.size.width - 2 * w, this.size.height - 2 * w)
                            drawArc(color = Color.White.copy(alpha = 0.12f), startAngle = -90f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                            drawArc(brush = Brush.sweepGradient(listOf(theme.a, theme.b, theme.a)), startAngle = -90f, sweepAngle = 360f * battery / 100f, useCenter = false, topLeft = tl, size = sz, style = Stroke(w, cap = StrokeCap.Round))
                        }
                        Text("$battery%", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
                    }
                }
                if (top.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    SectionLabel(tr("Mais usados", "Most used"))
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp), accent).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        top.forEach { AppIcon(it, shape, (size * 0.85f).dp, theme, duo, true, { launch(it) }, { onLong(it) }) }
                    }
                }
            }
        }
        }
        Text(tr("⌃  deslize para ver os apps", "⌃  swipe up for apps"), color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { openDrawer() }.padding(8.dp))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(34.dp), accent).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            dockApps.forEach { AppIcon(it, shape, size.dp, theme, duo, false, { launch(it) }, { onLong(it) }) }
        }
    }
    ThemeFan(fanOpen, orbCenter, themeIdx, { onTheme(it); fanOpen = false }, { fanOpen = false })
    }
}
