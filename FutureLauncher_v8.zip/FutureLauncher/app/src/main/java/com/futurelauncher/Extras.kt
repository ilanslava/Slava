package com.futurelauncher

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Easing com leve overshoot (a bolinha "pula" um pouco além e volta). */
private val BackOut = Easing { t -> val u = t - 1f; u * u * (2.70158f * u + 1.70158f) + 1f }

private val SurpriseRing = listOf(Color(0xFFFF5252), Color(0xFFFFD740), Color(0xFF69F0AE), Color(0xFF40C4FF), Color(0xFFE040FB), Color(0xFFFF5252))

/** Bolinha de cor. idx -1 é a bolinha "?" (modo surpresa, cor muda sozinha ao longo do dia). */
@Composable
fun ThemeDot(idx: Int, selected: Boolean, size: Dp, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val fill = if (idx < 0) Modifier.background(Brush.sweepGradient(SurpriseRing)) else Modifier.background(Brush.linearGradient(listOf(Themes[idx].a, Themes[idx].b)))
    Box(
        modifier.size(size).clip(CircleShape).then(fill)
            .border(if (selected) 3.dp else 1.dp, Color.White.copy(alpha = if (selected) 1f else 0.4f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (idx < 0) Text("?", color = Color.White, fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold)
    }
}

/** A bolinha do topo: mostra o gradiente do tema atual. Toque abre/fecha o painel de cores. */
@Composable
fun ThemeOrb(theme: Theme, open: Boolean, surprise: Boolean, onToggle: () -> Unit, onCenter: (Offset) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val rot by animateFloatAsState(if (open) 135f else 0f, spring(Spring.DampingRatioMediumBouncy), label = "orbRot")
    Box(
        Modifier.padding(6.dp).size(34.dp)
            .onGloballyPositioned { val p = it.positionInRoot(); onCenter(Offset(p.x + it.size.width / 2f, p.y + it.size.height / 2f)) }
            .clip(CircleShape)
            .clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onToggle() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { rotationZ = rot }
                .background(Brush.linearGradient(listOf(theme.a, theme.b)), CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
        )
        if (surprise) Text("?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PanelDot(n: Int, i: Int, go: Boolean, current: Int, onPick: (Int) -> Unit) {
    val pr by animateFloatAsState(if (go) 1f else 0f, tween(300, delayMillis = if (go) 60 + n * 12 else 0, easing = BackOut), label = "pd")
    ThemeDot(i, i == current, 34.dp, Modifier.graphicsLayer { scaleX = pr.coerceAtLeast(0f); scaleY = pr.coerceAtLeast(0f); alpha = pr.coerceIn(0f, 1f) }) { onPick(i) }
}

/** Painel com a bolinha "?" e as 33 cores. Abre a partir da bolinha do topo; cada cor entra em cascata. */
@Composable
fun ThemePanel(open: Boolean, center: Offset, current: Int, theme: Theme, onPick: (Int) -> Unit, onClose: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(open) { if (open) show = true else { delay(450); show = false } }
    if (!show) return
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(open) { go = open }
    val scrim = remember { MutableInteractionSource() }
    val own = remember { MutableInteractionSource() }
    val topPad = with(LocalDensity.current) { center.y.toDp() } + 28.dp
    val s by animateFloatAsState(if (go) 1f else 0f, tween(380, easing = BackOut), label = "panel")
    val all = listOf(-1) + Themes.indices.toList()
    val shape = RoundedCornerShape(22.dp)
    Box(Modifier.fillMaxSize().then(if (open) Modifier.clickable(interactionSource = scrim, indication = null) { onClose() } else Modifier)) {
        Column(
            Modifier.align(Alignment.TopEnd).padding(top = topPad, end = 14.dp).width(286.dp)
                .graphicsLayer { transformOrigin = TransformOrigin(1f, 0f); scaleX = s.coerceAtLeast(0f); scaleY = s.coerceAtLeast(0f); alpha = s.coerceIn(0f, 1f) }
                .clip(shape).background(Color(0xFF0B0620).copy(alpha = 0.93f)).border(1.dp, theme.a.copy(alpha = 0.7f), shape)
                .clickable(interactionSource = own, indication = null) { }
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "\$ theme --set " + (if (current < 0) "?" else Themes[current].name.lowercase()),
                color = theme.a, fontFamily = FontFamily.Monospace, fontSize = 12.sp
            )
            all.chunked(6).forEachIndexed { r, row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEachIndexed { c, i -> PanelDot(r * 6 + c, i, go, current, onPick) }
                }
            }
        }
    }
}

/** Onda de cor que se espalha a partir da bolinha toda vez que o tema muda. Não intercepta toque. */
@Composable
fun ThemeWave(key: Int, center: Offset, color: Color) {
    val prog = remember { Animatable(1f) }
    LaunchedEffect(key) { if (key > 0) { prog.snapTo(0f); prog.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) } }
    Canvas(Modifier.fillMaxSize()) {
        val v = prog.value
        if (v < 1f) {
            val r = hypot(size.width, size.height) * v
            drawCircle(color.copy(alpha = 0.30f * (1f - v)), r, center)
            drawCircle(color.copy(alpha = 0.9f * (1f - v)), r, center, style = Stroke(width = 5.dp.toPx() * (1f - v) + 1f))
        }
    }
}

/**
 * Esferas translúcidas em órbita lenta no fundo da home, no clima do boot do PS2.
 * Profundidade falsa: quando a esfera está "na frente" ela fica maior e mais brilhante.
 * Cada uma deixa um rastro curto. As cores seguem o tema. Não intercepta toque.
 */
@Composable
fun LivingOrbs(theme: Theme, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ps2")
    val ph by t.animateFloat(0f, 1f, infiniteRepeatable(tween(120000, easing = LinearEasing)), label = "ph")
    val cxs = floatArrayOf(0.50f, 0.35f, 0.65f, 0.50f)
    val cys = floatArrayOf(0.30f, 0.55f, 0.70f, 0.45f)
    val rxs = floatArrayOf(0.38f, 0.30f, 0.34f, 0.22f)
    val rys = floatArrayOf(0.14f, 0.18f, 0.12f, 0.20f)
    val spd = intArrayOf(4, 6, 5, 7)
    val off = floatArrayOf(0.00f, 0.25f, 0.55f, 0.80f)
    val rad = floatArrayOf(20f, 30f, 14f, 24f)
    Canvas(modifier) {
        val tau = 6.2831855f
        val cols = listOf(theme.a, theme.b, Color.White, theme.a)
        for (i in 0 until 4) {
            val col = cols[i]
            for (j in 8 downTo 0) {
                val a = tau * (ph * spd[i] + off[i]) - j * 0.07f
                val z = (sin(a) + 1f) / 2f
                val c = Offset(size.width * (cxs[i] + rxs[i] * cos(a)), size.height * (cys[i] + rys[i] * sin(a)))
                val r = rad[i].dp.toPx() * (0.7f + 0.6f * z) * (1f - j * 0.07f)
                val al = (0.55f + 0.45f * z) * (if (j == 0) 1f else 0.34f * (1f - j / 9f))
                if (j == 0) drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.55f * al), Color.Transparent), c, r * 3.6f), r * 3.6f, c)
                drawCircle(
                    Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f * al), col.copy(alpha = 0.65f * al), col.copy(alpha = 0.10f * al)), Offset(c.x - r * 0.3f, c.y - r * 0.3f), r * 1.4f),
                    r, c
                )
            }
        }
    }
}
