@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.futurelauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)
    private var homeTick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { LauncherApp(resumeTick, homeTick) }
    }
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); homeTick++ }
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap, val cat: Int = -1)
data class Theme(val name: String, val a: Color, val b: Color)

val Themes = listOf(
    Theme("Neon", Color(0xFF00E5FF), Color(0xFF7C4DFF)), Theme("Roxo", Color(0xFFE040FB), Color(0xFF6A1B9A)),
    Theme("Sunset", Color(0xFFFF4081), Color(0xFFFFAB40)), Theme("Matrix", Color(0xFF69F0AE), Color(0xFF00897B)),
    Theme("Gelo", Color(0xFF82B1FF), Color(0xFFB2EBF2)), Theme("Fogo", Color(0xFFFF5252), Color(0xFFFF9100)),
    Theme("Ouro", Color(0xFFFFD740), Color(0xFFFF6F00)), Theme("Rosa", Color(0xFFFF80AB), Color(0xFFAD1457)),
    Theme("Ciano", Color(0xFF18FFFF), Color(0xFF00B8D4)), Theme("Lima", Color(0xFFC6FF00), Color(0xFF64DD17)),
    Theme("Laranja", Color(0xFFFF9100), Color(0xFFFF3D00)), Theme("Violeta", Color(0xFFB388FF), Color(0xFF651FFF)),
    Theme("Oceano", Color(0xFF40C4FF), Color(0xFF0D47A1)), Theme("Menta", Color(0xFF64FFDA), Color(0xFF00BFA5)),
    Theme("Magenta", Color(0xFFF50057), Color(0xFF880E4F)), Theme("Sangue", Color(0xFFFF1744), Color(0xFFB71C1C)),
    Theme("Âmbar", Color(0xFFFFC400), Color(0xFFFF8F00)), Theme("Esmeralda", Color(0xFF00E676), Color(0xFF1B5E20)),
    Theme("Safira", Color(0xFF2979FF), Color(0xFF1A237E)), Theme("Lavanda", Color(0xFFD1C4E9), Color(0xFF7E57C2)),
    Theme("Pêssego", Color(0xFFFFAB91), Color(0xFFFF7043)), Theme("Aqua", Color(0xFF1DE9B6), Color(0xFF00B0FF)),
    Theme("Uva", Color(0xFFAB47BC), Color(0xFF4A148C)), Theme("Coral", Color(0xFFFF8A65), Color(0xFFE64A19)),
    Theme("Limão", Color(0xFFFFFF00), Color(0xFFAEEA00)), Theme("Céu", Color(0xFF80D8FF), Color(0xFF448AFF)),
    Theme("Cobre", Color(0xFFD7843B), Color(0xFF6D3A1F)), Theme("Prata", Color(0xFFCFD8DC), Color(0xFF607D8B)),
    Theme("Pop", Color(0xFFFF00A8), Color(0xFF00E5FF)), Theme("Tóxico", Color(0xFF76FF03), Color(0xFF00E5FF)),
    Theme("Aurora", Color(0xFF69F0AE), Color(0xFFB388FF)), Theme("Vulcão", Color(0xFFFF3D00), Color(0xFF6200EA)),
    Theme("Branco", Color(0xFFFFFFFF), Color(0xFF90A4AE))
)

/** Modo "?": uma cor sorteada que muda sozinha a cada hora (sempre a mesma dentro da mesma hora). */
fun surpriseSeed(): Int {
    val n = LocalDateTime.now()
    return java.util.Random(n.toLocalDate().toEpochDay() * 24 + n.hour).nextInt(Themes.size)
}

enum class IconShape { Circle, Squircle, Hex;
    fun label() = when (this) { Circle -> tr("Círculo", "Circle"); Squircle -> tr("Quadrado", "Square"); Hex -> tr("Hexágono", "Hexagon") }
}

val HexShape = GenericShape { size, _ ->
    val r = size.minDimension / 2f
    val cx = size.width / 2f
    val cy = size.height / 2f
    for (i in 0 until 6) {
        val a = Math.toRadians((60 * i - 90).toDouble())
        val x = cx + r * cos(a).toFloat()
        val y = cy + r * sin(a).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

fun IconShape.toShape(): Shape = when (this) {
    IconShape.Circle -> CircleShape
    IconShape.Squircle -> RoundedCornerShape(30)
    IconShape.Hex -> HexShape
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(144, 144).asImageBitmap(), it.activityInfo.applicationInfo.category) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun Modifier.glass(shape: Shape, accent: Color): Modifier = this
    .clip(shape)
    .background(Color.Black.copy(alpha = 0.30f))
    .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), accent.copy(alpha = 0.04f))))
    .border(1.2.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.9f), Color.White.copy(alpha = 0.06f))), shape)

fun Modifier.duotone(a: Color, b: Color): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        drawRect(Brush.linearGradient(listOf(a, b)), blendMode = BlendMode.Color)
    }

@Composable
fun LauncherApp(resumeTick: Int, homeTick: Int) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE).also { it.edit().remove("sales").remove("replies").apply() } }
    var shape by remember { mutableStateOf(IconShape.valueOf(prefs.getString("shape", "Squircle")!!)) }
    var themeIdx by remember { mutableStateOf(prefs.getInt("theme", 0)) }
    var duo by remember { mutableStateOf(prefs.getBoolean("duo", false)) }
    var iconSize by remember { mutableStateOf(prefs.getFloat("size", 58f)) }
    var dock by remember { mutableStateOf(prefs.getString("dock", "")!!.split(",").filter { it.isNotBlank() }) }
    var selected by remember { mutableStateOf<AppInfo?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    var aiProvider by remember { mutableStateOf(prefs.getInt("ai_provider", 0)) }
    var aiKey by remember { mutableStateOf(prefs.getString("ai_key", "")!!) }
    var aiModel by remember { mutableStateOf(prefs.getString("ai_model", "")!!.ifBlank { aiDefaultModel(aiProvider) }) }
    var aiPersona by remember { mutableStateOf(prefs.getInt("ai_persona", 0)) }
    var aiP0 by remember { mutableStateOf(prefs.getString("ai_p0", null) ?: PersonaDefaults[0]) }
    var aiP1 by remember { mutableStateOf(prefs.getString("ai_p1", null) ?: PersonaDefaults[1]) }
    var layout by remember { mutableStateOf(prefs.getInt("layout", 2)) }
    var favs by remember { mutableStateOf(prefs.getString("favs", "")!!.split(",").filter { it.isNotBlank() }.toSet()) }
    var usageRev by remember { mutableStateOf(0) }
    val seed by produceState(surpriseSeed()) { while (true) { delay(60_000); value = surpriseSeed() } }
    val target = if (themeIdx < 0) Themes[seed] else Themes[themeIdx.coerceIn(0, Themes.size - 1)]
    val ca by animateColorAsState(target.a, tween(450), label = "ta")
    val cb by animateColorAsState(target.b, tween(450), label = "tb")
    val theme = Theme(target.name, ca, cb)
    val accent = theme.a

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = theme.a, onPrimary = Color.Black, secondary = theme.b, onSecondary = Color.Black,
            secondaryContainer = theme.a.copy(alpha = 0.35f), onSecondaryContainer = Color.White,
            background = Color(0xFF0B0620), onBackground = Color.White, surface = Color(0xFF0B0620), onSurface = Color.White,
            surfaceVariant = Color(0xFF1B1238), onSurfaceVariant = Color.White.copy(alpha = 0.7f),
            surfaceContainerHigh = Color(0xFF120A2E), outline = theme.a.copy(alpha = 0.6f)
        )
    ) {
    val apps by produceState(emptyList<AppInfo>(), resumeTick) { value = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val dockApps = dock.mapNotNull { p -> apps.find { it.pkg == p } }.ifEmpty { apps.take(4) }
    val top = remember(apps, usageRev) {
        apps.filter { prefs.getInt("n_" + it.pkg, 0) > 0 }.sortedByDescending { prefs.getInt("n_" + it.pkg, 0) }.take(4)
    }

    val pager = rememberPagerState(pageCount = { 2 })
    LaunchedEffect(homeTick) { if (homeTick > 0) pager.animateScrollToPage(0) }
    BackHandler(pager.currentPage == 1) { scope.launch { pager.animateScrollToPage(0) } }
    val p = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)

    val launch: (AppInfo) -> Unit = { app ->
        prefs.edit().putInt("n_" + app.pkg, prefs.getInt("n_" + app.pkg, 0) + 1).apply()
        usageRev++
        ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let { ctx.startActivity(it) }
    }
    val longPress: (AppInfo) -> Unit = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); selected = it }

    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "g")

    Box(
        Modifier.fillMaxSize().drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.34f + 0.5f * p), Color(0xFF0B0620).copy(alpha = 0.58f + 0.32f * p))))
            drawRect(Brush.verticalGradient(listOf(theme.a.copy(alpha = 0.26f * (1f - 0.6f * p)), Color.Transparent, theme.b.copy(alpha = 0.32f * (1f - 0.6f * p)))))
            val c = Offset(size.width * (0.15f + 0.7f * glow), size.height * 0.28f)
            drawCircle(Brush.radialGradient(listOf(theme.a.copy(alpha = 0.55f), Color.Transparent), c, size.width * 0.8f), radius = size.width * 0.8f, center = c)
            val c2 = Offset(size.width * (0.85f - 0.7f * glow), size.height * 0.8f)
            drawCircle(Brush.radialGradient(listOf(theme.b.copy(alpha = 0.50f), Color.Transparent), c2, size.width * 0.7f), radius = size.width * 0.7f, center = c2)
            for (i in 0 until 16) {
                val px = (((i * 37) % 100) / 100f + 0.03f * sin(glow * 6.28f * (1 + i % 3) + i)) * size.width
                val py = (((i * 61) % 100) / 100f + 0.04f * sin(glow * 6.28f * (1 + i % 2) + i * 2f)) * size.height
                drawCircle(Color.White.copy(alpha = 0.10f + 0.05f * (i % 3)), radius = (1.5f + i % 3).dp.toPx(), center = Offset(px, py))
            }
        }
    ) {
        VerticalPager(pager, Modifier.fillMaxSize()) { page ->
            if (page == 0) Box(Modifier.graphicsLayer { alpha = 1f - p; scaleX = 1f - 0.1f * p; scaleY = 1f - 0.1f * p }) {
                HomePage(dockApps, top, shape, iconSize, duo, theme, apps.size, layout, prefs, apps, { scope.launch { pager.animateScrollToPage(1) } }, { showSettings = true }, { if (aiKey.isNotBlank()) showAi = true else openVoiceAssistant(ctx) }, { c -> runCommand(ctx, c, apps, launch) }, launch, longPress, themeIdx, { i -> themeIdx = i; prefs.edit().putInt("theme", i).apply() }, { openVoiceAssistant(ctx) })
            } else Box(Modifier.graphicsLayer { alpha = p; translationY = (1f - p) * 120f }) {
                DrawerPage(apps, shape, iconSize, duo, theme, prefs, favs, { app -> launch(app); scope.launch { pager.scrollToPage(0) } }, longPress)
            }
        }
    }

    if (showAi) AiChat(theme, aiProvider, aiKey, aiModel, aiPersona, if (aiPersona == 0) aiP0 else aiP1, { i -> aiPersona = i; prefs.edit().putInt("ai_persona", i).apply() }) { showAi = false }

    selected?.let { app ->
        val pinned = app.pkg in dock
        val fav = app.pkg in favs
        HackSheet(app.label.lowercase(), theme, { selected = null }) {
            HackOpt(if (pinned) tr("tirar do dock", "unpin from dock") else tr("fixar no dock", "pin to dock")) {
                dock = if (pinned) dock - app.pkg else (dock + app.pkg).takeLast(5)
                prefs.edit().putString("dock", dock.joinToString(",")).apply(); selected = null
            }
            HackOpt(if (fav) tr("remover dos favoritos ★", "remove from favorites ★") else tr("favoritar ★", "favorite ★")) {
                favs = if (fav) favs - app.pkg else favs + app.pkg
                prefs.edit().putString("favs", favs.joinToString(",")).apply(); selected = null
            }
            HackOpt(tr("info do app", "app info")) {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))); selected = null
            }
            HackOpt(tr("desinstalar", "uninstall")) {
                runCatching { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))) }; selected = null
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text(tr("Personalizar", "Customize")) },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text(tr("Pronto", "Done")) } },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(tr("Tema", "Theme"))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        (listOf(-1) + Themes.indices.toList()).forEach { i ->
                            ThemeDot(i, themeIdx == i, 32.dp) { themeIdx = i; prefs.edit().putInt("theme", i).apply() }
                        }
                    }
                    Text(tr("Layout da home", "Home layout"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(tr("Mínimo", "Minimal"), tr("Clássico", "Classic"), "Hub").forEachIndexed { i, n ->
                            FilterChip(selected = layout == i, onClick = { layout = i; prefs.edit().putInt("layout", i).apply() }, label = { Text(n, fontSize = 12.sp) })
                        }
                    }
                    Text(tr("Formato dos ícones", "Icon shape"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconShape.values().forEach { s ->
                            FilterChip(selected = shape == s, onClick = { shape = s; prefs.edit().putString("shape", s.name).apply() }, label = { Text(s.label(), fontSize = 12.sp) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("Ícones duotone (cor do tema)", "Duotone icons (theme color)"))
                        Switch(checked = duo, onCheckedChange = { duo = it; prefs.edit().putBoolean("duo", it).apply() })
                    }
                    Text(tr("Tamanho dos ícones", "Icon size"))
                    Slider(value = iconSize, onValueChange = { iconSize = it; prefs.edit().putFloat("size", it).apply() }, valueRange = 44f..76f)
                    Text(tr("Assistente IA (toque no microfone)", "AI assistant (mic tap)"))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AiProviders.forEachIndexed { i, n ->
                            FilterChip(
                                selected = aiProvider == i,
                                onClick = {
                                    aiProvider = i; prefs.edit().putInt("ai_provider", i).apply()
                                    if (aiModel.isBlank() || AiProviders.indices.any { aiModel == aiDefaultModel(it) }) {
                                        aiModel = aiDefaultModel(i); prefs.edit().putString("ai_model", aiModel).apply()
                                    }
                                },
                                label = { Text(n, fontSize = 12.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = aiKey, onValueChange = { aiKey = it; prefs.edit().putString("ai_key", it.trim()).apply() },
                        label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()
                    )
                    OutlinedTextField(
                        value = aiModel, onValueChange = { aiModel = it; prefs.edit().putString("ai_model", it.trim()).apply() },
                        label = { Text(tr("Modelo", "Model")) }, singleLine = true
                    )
                    Text(tr("Personalidade da IA", "AI personality"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PersonaNames.forEachIndexed { i, n ->
                            FilterChip(selected = aiPersona == i, onClick = { aiPersona = i; prefs.edit().putInt("ai_persona", i).apply() }, label = { Text(n, fontSize = 12.sp) })
                        }
                    }
                    OutlinedTextField(
                        value = if (aiPersona == 0) aiP0 else aiP1,
                        onValueChange = {
                            if (aiPersona == 0) { aiP0 = it; prefs.edit().putString("ai_p0", it).apply() } else { aiP1 = it; prefs.edit().putString("ai_p1", it).apply() }
                        },
                        label = { Text(tr("Como ela age", "How it behaves")) }, minLines = 3
                    )
                    Text(tr("Sem chave, o toque no 🎤 abre o assistente do Google. Segurar o 🎤 sempre abre o do Google.", "With no key, tapping 🎤 opens the Google assistant. Long-press 🎤 always opens Google's."), fontSize = 11.sp)
                }
            }
        )
    }
    }
}

@Composable
fun AppIcon(app: AppInfo, shape: IconShape, size: Dp, theme: Theme, duo: Boolean, showLabel: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val s = shape.toShape()
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.8f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press")
    Column(
        Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.icon, contentDescription = app.label,
            modifier = Modifier.size(size).clip(s).background(Color.White.copy(alpha = 0.08f))
                .then(if (duo) Modifier.duotone(theme.a, theme.b) else Modifier)
                .border(1.dp, theme.a.copy(alpha = 0.45f), s)
        )
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(size + 12.dp))
        }
    }
}
