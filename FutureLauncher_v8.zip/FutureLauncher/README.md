# Future Launcher v8
Build: suba tudo pro GitHub -> Actions -> "Build APK" -> baixe FutureLauncher-APK. Desinstale a versao anterior antes.
Home: 3 layouts (Minimo, Classico, Hub) na engrenagem. Hub = atalhos, Instagram (story/reels/post), foco 33 min.
Gaveta: abas (Todos, Favoritos, categorias), grade/lista, barra A-Z lateral, Enter abre o 1o resultado. Segure um app: dock, favorito, info, desinstalar.
v7: assistente orb vivo, atalhos de apps, Instagram story\/reels\/post, timer 33 (digite: timer 33).
v8: bolinha de tema na home (leque de cores, 8 temas), gaveta de apps em estilo terminal hacker (cor segue o tema), microfone abre o assistente padrao do sistema (Gemini/Assistant) via ACTION_ASSIST. v8.1: corrigidos imports que faltavam (build do GitHub Actions).
v8.2: removido tudo que era de clientes/vendas (contador, respostas rapidas, frases do orb) e as chaves antigas salvas no aparelho.
v8.3: esferas em orbita lenta no fundo da home (estilo boot do PS2), seguem a cor do tema.
v8.4: microfone com IA propria: engrenagem > Assistente IA (Claude, OpenAI ou Gemini, chave e modelo). Toque no mic abre o chat por voz/texto; segurar o mic abre o assistente do Google. Sem chave, o toque abre o Google.
v8.5: tema mais forte (lavagem de cor, cards tingidos, brilho no relogio, onda ao trocar), painel com bolinha "?" (cor muda a cada hora) e 33 cores, menu de app e seletores no estilo hacker, barra de comando em uma linha com X, atalhos com "+" fixo e seletor de apps, "Postar em" com escolha do app e opcoes que ele aceita, Foco cria alarme normal (33, 11, 7 ou ? com teclado), icone proprio do app, personalidades Spencer e Kristen (editaveis) e OpenRouter.
